shared_examples 'database::init' do
	set :os, :family => 'suse'
	
	# return if 'not_available' property set for the host
	next if property[:not_available] == true

	describe command('hostname') do
		its(:stdout) { should match ENV['TARGET_HOST'] }
	end
end