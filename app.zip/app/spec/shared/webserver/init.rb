shared_examples 'webserver::init' do
	set :os, :family => 'suse'

	# return if 'not_available' property set for the host
	next if property[:not_available] == true
	
	describe command('hostname') do
		its(:stdout) { should match ENV['TARGET_HOST'] }
	end
	
	# ensure that the platform details exist
	include_examples 'base::init'
	
end