shared_examples 'appserver::init' do
	set :os, :family => 'suse'

	print "The property is "
	puts property[:not_available]
	
	# return if 'not_available' property set for the host
	next if property[:not_available] == true
	
	describe command('hostname') do
		its(:stdout) { should match ENV['TARGET_HOST'] }
	end

end