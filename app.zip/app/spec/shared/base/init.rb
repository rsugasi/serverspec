shared_examples 'base::init' do

	describe host_inventory['platform'] do
		it { should match 'sles' }
	end
	
	describe host_inventory['platform_version'] do
		it { should match '11' }
	end
	
end