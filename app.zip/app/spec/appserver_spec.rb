require 'spec_helper'

describe 'appserver' do
  include_examples 'appserver::init'
end