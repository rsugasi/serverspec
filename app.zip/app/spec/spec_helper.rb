# gem install serverspec
require 'serverspec'
require 'net/ssh'
# gem install net-ssh-krb
require 'net/ssh/kerberos'
require 'resolv'
require 'pathname'
require 'yaml'

base_spec_dir = Pathname.new(File.join(File.dirname(__FILE__)))

Dir[base_spec_dir.join('shared/**/*.rb')].sort.each{ |f| require f }

set :backend, :ssh

host = ENV['TARGET_HOST']

properties = YAML.load_file(base_spec_dir.join('properties.yml'))
set_property properties[host]

print host
print " => "
# since we are unable to perform reverse-lookup of hostname
# retrieve the the IP address manually using resolv library.
Resolv.each_address(host) do |ip|
  host = ip
end
puts host

options = Net::SSH::Config.for(host)

options[:user] ||= Etc.getlogin
options[:auth_methods] = ["gssapi-with-mic"]

set :host,        options[:host_name] || host
set :ssh_options, options

# Disable sudo
set :disable_sudo, true
